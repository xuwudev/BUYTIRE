--
-- PostgreSQL database dump
--

\restrict 4gwTJk1Ajof9PH7pHob4DCIG89dPsOsy57n2pajh29b4XsYAUXlOb9WsDqLuU2o

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.1

-- Started on 2026-03-26 10:44:54

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 226 (class 1259 OID 16651)
-- Name: cart_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_items (
    id integer NOT NULL,
    user_id integer,
    product_id integer,
    quantity integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.cart_items OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 16650)
-- Name: cart_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cart_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cart_items_id_seq OWNER TO postgres;

--
-- TOC entry 5104 (class 0 OID 0)
-- Dependencies: 225
-- Name: cart_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cart_items_id_seq OWNED BY public.cart_items.id;


--
-- TOC entry 220 (class 1259 OID 16604)
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name_uk character varying(100) NOT NULL,
    type character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT categories_type_check CHECK (((type)::text = ANY ((ARRAY['tire'::character varying, 'wheel'::character varying])::text[])))
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16603)
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO postgres;

--
-- TOC entry 5105 (class 0 OID 0)
-- Dependencies: 219
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- TOC entry 230 (class 1259 OID 16692)
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer,
    product_id integer,
    quantity integer NOT NULL,
    price_at_time numeric(10,2) NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 16691)
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO postgres;

--
-- TOC entry 5106 (class 0 OID 0)
-- Dependencies: 229
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- TOC entry 228 (class 1259 OID 16671)
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    user_id integer,
    order_number character varying(50),
    total_amount numeric(10,2) NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    payment_status character varying(20) DEFAULT 'unpaid'::character varying,
    shipping_address text,
    phone character varying(20),
    comment text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 16670)
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- TOC entry 5107 (class 0 OID 0)
-- Dependencies: 227
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- TOC entry 222 (class 1259 OID 16615)
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    category_id integer,
    name_uk character varying(200) NOT NULL,
    brand character varying(50),
    model character varying(100),
    price numeric(10,2) NOT NULL,
    old_price numeric(10,2),
    quantity integer DEFAULT 0,
    description_uk text,
    specifications jsonb,
    images text[],
    width integer,
    profile integer,
    diameter integer,
    season character varying(20),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.products OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16614)
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO postgres;

--
-- TOC entry 5108 (class 0 OID 0)
-- Dependencies: 221
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- TOC entry 232 (class 1259 OID 16712)
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    id integer NOT NULL,
    product_id integer,
    user_id integer,
    rating integer,
    comment_uk text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 16711)
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reviews_id_seq OWNER TO postgres;

--
-- TOC entry 5109 (class 0 OID 0)
-- Dependencies: 231
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- TOC entry 224 (class 1259 OID 16635)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(100),
    phone character varying(20),
    address text,
    role character varying(20) DEFAULT 'user'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 16634)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- TOC entry 5110 (class 0 OID 0)
-- Dependencies: 223
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 4895 (class 2604 OID 16654)
-- Name: cart_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items ALTER COLUMN id SET DEFAULT nextval('public.cart_items_id_seq'::regclass);


--
-- TOC entry 4886 (class 2604 OID 16607)
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- TOC entry 4902 (class 2604 OID 16695)
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- TOC entry 4898 (class 2604 OID 16674)
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- TOC entry 4888 (class 2604 OID 16618)
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- TOC entry 4903 (class 2604 OID 16715)
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- TOC entry 4892 (class 2604 OID 16638)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 5092 (class 0 OID 16651)
-- Dependencies: 226
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_items (id, user_id, product_id, quantity, created_at) FROM stdin;
\.


--
-- TOC entry 5086 (class 0 OID 16604)
-- Dependencies: 220
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name_uk, type, created_at) FROM stdin;
1	Літні шини	tire	2026-03-25 13:03:21.905778
2	Зимові шини	tire	2026-03-25 13:03:21.905778
3	Всесезонні шини	tire	2026-03-25 13:03:21.905778
4	Легкосплавні диски	wheel	2026-03-25 13:03:21.905778
5	Сталеві диски	wheel	2026-03-25 13:03:21.905778
\.


--
-- TOC entry 5096 (class 0 OID 16692)
-- Dependencies: 230
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, order_id, product_id, quantity, price_at_time) FROM stdin;
\.


--
-- TOC entry 5094 (class 0 OID 16671)
-- Dependencies: 228
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, user_id, order_number, total_amount, status, payment_status, shipping_address, phone, comment, created_at) FROM stdin;
\.


--
-- TOC entry 5088 (class 0 OID 16615)
-- Dependencies: 222
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, category_id, name_uk, brand, model, price, old_price, quantity, description_uk, specifications, images, width, profile, diameter, season, is_active, created_at) FROM stdin;
1	1	Michelin Pilot Sport 4	Michelin	\N	3850.00	4500.00	15	Високопродуктивна літня шина для спортивних автомобілів. Відмінне зчеплення на сухому та мокрому покритті.	{"Шум": "71 dB", "Індекс швидкості": "Y", "Індекс навантаження": "94"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	225	45	17	summer	t	2026-03-25 13:03:21.908954
2	1	Continental PremiumContact 6	Continental	\N	3250.00	3800.00	22	Комфортна та безпечна літня шина для міських автомобілів.	{"Шум": "69 dB", "Індекс швидкості": "V", "Індекс навантаження": "91"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	205	55	16	summer	t	2026-03-25 13:03:21.911647
3	1	Pirelli Cinturato P7	Pirelli	\N	2950.00	\N	18	Екологічна шина з низьким опором коченню.	{"Шум": "70 dB", "Індекс швидкості": "W", "Індекс навантаження": "93"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	215	50	17	summer	t	2026-03-25 13:03:21.912245
4	1	Goodyear EfficientGrip Performance	Goodyear	\N	2780.00	\N	25	Економічна шина з покращеною паливною ефективністю.	{"Шум": "68 dB", "Індекс швидкості": "H", "Індекс навантаження": "95"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	195	65	15	summer	t	2026-03-25 13:03:21.912789
5	1	Bridgestone Turanza T005	Bridgestone	\N	3450.00	\N	12	Преміальна шина з відмінним зчепленням на мокрому покритті.	{"Шум": "72 dB", "Індекс швидкості": "Y", "Індекс навантаження": "92"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	225	45	18	summer	t	2026-03-25 13:03:21.913366
6	2	Nokian Hakkapeliitta R3	Nokian	\N	4250.00	4900.00	8	Скандинавська зимова шина з відмінним зчепленням на льоду та снігу.	{"Шум": "72 dB", "Індекс швидкості": "T", "Індекс навантаження": "94"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	205	55	16	winter	t	2026-03-25 13:03:21.913932
7	2	Michelin Alpin 6	Michelin	\N	3980.00	\N	14	Європейська зимова шина з відмінною керованістю.	{"Шум": "71 dB", "Індекс швидкості": "H", "Індекс навантаження": "95"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	215	50	17	winter	t	2026-03-25 13:03:21.91451
8	2	Continental WinterContact TS 870	Continental	\N	3750.00	\N	10	Німецька якість для безпечної зимової їзди.	{"Шум": "70 dB", "Індекс швидкості": "T", "Індекс навантаження": "92"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	205	60	16	winter	t	2026-03-25 13:03:21.915096
9	2	Goodyear UltraGrip Performance 3	Goodyear	\N	3420.00	\N	16	Високоефективна зимова шина для м'яких зим.	{"Шум": "73 dB", "Індекс швидкості": "V", "Індекс навантаження": "94"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	225	45	18	winter	t	2026-03-25 13:03:21.915587
10	3	Michelin CrossClimate 2	Michelin	\N	4150.00	\N	9	Інноваційна всесезонна шина з позначкою 3PMSF.	{"Шум": "71 dB", "Індекс швидкості": "V", "Індекс навантаження": "94"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	215	55	17	all-season	t	2026-03-25 13:03:21.916075
11	3	Goodyear Vector 4Seasons Gen-3	Goodyear	\N	3680.00	\N	11	Надійна всесезонна шина для українських доріг.	{"Шум": "70 dB", "Індекс швидкості": "H", "Індекс навантаження": "96"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	205	60	16	all-season	t	2026-03-25 13:03:21.916488
12	4	BBS CH-R 18"	BBS	\N	18500.00	22000.00	4	Німецькі легкосплавні диски преміум класу.	{"ET": "35", "PCD": "5x112", "Колір": "Сріблястий", "Розмір": "18x8.5"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	\N	\N	18	\N	t	2026-03-25 13:03:21.916872
13	4	OZ Racing Superturismo LM	OZ Racing	\N	15200.00	\N	6	Італійські спортивні диски.	{"ET": "40", "PCD": "5x114.3", "Колір": "Матова чорний", "Розмір": "17x7.5"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	\N	\N	17	\N	t	2026-03-25 13:03:21.917249
14	4	Enkei RPF1	Enkei	\N	16800.00	\N	3	Легкі та міцні японські диски.	{"ET": "38", "PCD": "5x100", "Колір": "Золотий", "Розмір": "18x9"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	\N	\N	18	\N	t	2026-03-25 13:03:21.917638
15	4	AEZ Porto	AEZ	\N	12400.00	\N	8	Німецькі диски в класичному стилі.	{"ET": "45", "PCD": "5x108", "Колір": "Сріблястий", "Розмір": "16x7"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	\N	\N	16	\N	t	2026-03-25 13:03:21.918006
16	5	Сталевий диск 15"	Steel	\N	1850.00	\N	20	Надійний сталевий диск для зимових шин.	{"ET": "35", "PCD": "4x100", "Колір": "Чорний", "Розмір": "15x6"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	\N	\N	15	\N	t	2026-03-25 13:03:21.918373
17	5	Сталевий диск 16"	Steel	\N	2250.00	\N	15	Універсальний сталевий диск для будь-якого автомобіля.	{"ET": "38", "PCD": "5x112", "Колір": "Чорний", "Розмір": "16x6.5"}	{https://img.freepik.com/premium-psd/high-performance-tire-with-black-alloy-wheel_585128-299.jpg}	\N	\N	16	\N	t	2026-03-25 13:03:21.918772
\.


--
-- TOC entry 5098 (class 0 OID 16712)
-- Dependencies: 232
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (id, product_id, user_id, rating, comment_uk, created_at) FROM stdin;
\.


--
-- TOC entry 5090 (class 0 OID 16635)
-- Dependencies: 224
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, full_name, phone, address, role, created_at) FROM stdin;
1	gakurocommercial@gmail.com	$2a$10$MpGb/YkCWxC9kLss2/6Ld.kL7vnUhWYcQI/8Sae7c5VKUIi/9RhfK	Maksym Maslo	+48512743282	\N	user	2026-03-25 12:51:25.726193
2	test@example.com	$2a$10$vmvtpWBb5FjOudzO2dom4.9h8b2B2lbx6e.L2MGACKLKGAxmTikKW	Тестовий Користувач	+380501234567	\N	user	2026-03-25 13:03:21.990532
\.


--
-- TOC entry 5111 (class 0 OID 0)
-- Dependencies: 225
-- Name: cart_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cart_items_id_seq', 1, false);


--
-- TOC entry 5112 (class 0 OID 0)
-- Dependencies: 219
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_id_seq', 5, true);


--
-- TOC entry 5113 (class 0 OID 0)
-- Dependencies: 229
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- TOC entry 5114 (class 0 OID 0)
-- Dependencies: 227
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, false);


--
-- TOC entry 5115 (class 0 OID 0)
-- Dependencies: 221
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 17, true);


--
-- TOC entry 5116 (class 0 OID 0)
-- Dependencies: 231
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reviews_id_seq', 1, false);


--
-- TOC entry 5117 (class 0 OID 0)
-- Dependencies: 223
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- TOC entry 4919 (class 2606 OID 16659)
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4908 (class 2606 OID 16613)
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- TOC entry 4927 (class 2606 OID 16700)
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4923 (class 2606 OID 16685)
-- Name: orders orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_number_key UNIQUE (order_number);


--
-- TOC entry 4925 (class 2606 OID 16683)
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- TOC entry 4913 (class 2606 OID 16628)
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- TOC entry 4929 (class 2606 OID 16722)
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- TOC entry 4915 (class 2606 OID 16649)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 4917 (class 2606 OID 16647)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4920 (class 1259 OID 16737)
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_status ON public.orders USING btree (status);


--
-- TOC entry 4921 (class 1259 OID 16736)
-- Name: idx_orders_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_orders_user ON public.orders USING btree (user_id);


--
-- TOC entry 4909 (class 1259 OID 16734)
-- Name: idx_products_brand; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_brand ON public.products USING btree (brand);


--
-- TOC entry 4910 (class 1259 OID 16733)
-- Name: idx_products_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_category ON public.products USING btree (category_id);


--
-- TOC entry 4911 (class 1259 OID 16735)
-- Name: idx_products_diameter; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_products_diameter ON public.products USING btree (diameter);


--
-- TOC entry 4931 (class 2606 OID 16665)
-- Name: cart_items cart_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4932 (class 2606 OID 16660)
-- Name: cart_items cart_items_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4934 (class 2606 OID 16701)
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- TOC entry 4935 (class 2606 OID 16706)
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- TOC entry 4933 (class 2606 OID 16686)
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 4930 (class 2606 OID 16629)
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- TOC entry 4936 (class 2606 OID 16723)
-- Name: reviews reviews_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4937 (class 2606 OID 16728)
-- Name: reviews reviews_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


-- Completed on 2026-03-26 10:44:54

--
-- PostgreSQL database dump complete
--

\unrestrict 4gwTJk1Ajof9PH7pHob4DCIG89dPsOsy57n2pajh29b4XsYAUXlOb9WsDqLuU2o

